const contributionImage = "/assets/contribution.svg";

export { contributionImage as default };
