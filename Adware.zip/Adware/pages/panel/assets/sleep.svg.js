const sleep = "/assets/sleep.svg";

export { sleep as default };
