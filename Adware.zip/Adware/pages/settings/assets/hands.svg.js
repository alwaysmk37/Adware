const __vite_glob_0_3 = "/assets/hands.svg";

export { __vite_glob_0_3 as default };
