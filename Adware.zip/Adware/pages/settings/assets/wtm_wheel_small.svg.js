const __vite_glob_0_11 = "/assets/wtm_wheel_small.svg";

export { __vite_glob_0_11 as default };
