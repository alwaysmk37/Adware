const __vite_glob_0_9 = "/assets/trackers_preview_small.svg";

export { __vite_glob_0_9 as default };
