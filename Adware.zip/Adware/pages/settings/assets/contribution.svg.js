const __vite_glob_0_0 = "/assets/contribution2.svg";

export { __vite_glob_0_0 as default };
