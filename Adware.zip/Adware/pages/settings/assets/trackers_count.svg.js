const __vite_glob_0_6 = "/assets/trackers_count.svg";

export { __vite_glob_0_6 as default };
