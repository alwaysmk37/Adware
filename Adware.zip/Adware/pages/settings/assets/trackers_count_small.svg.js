const __vite_glob_0_7 = "/assets/trackers_count_small.svg";

export { __vite_glob_0_7 as default };
