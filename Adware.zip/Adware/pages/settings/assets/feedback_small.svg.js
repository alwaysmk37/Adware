const __vite_glob_0_2 = "/assets/feedback_small.svg";

export { __vite_glob_0_2 as default };
