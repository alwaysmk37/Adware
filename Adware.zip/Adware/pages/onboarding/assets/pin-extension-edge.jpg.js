const pinExtensionEdge = "/assets/pin-extension-edge.jpg";

export { pinExtensionEdge as default };
