const pinExtensionChrome = "/assets/pin-extension-chrome.jpg";

export { pinExtensionChrome as default };
