import __vite_glob_0_0 from './components/action-button-group.js';
import __vite_glob_0_1 from './components/action-button.js';
import __vite_glob_0_2 from './components/action.js';
import __vite_glob_0_3 from './components/badge.js';
import __vite_glob_0_4 from './components/button.js';
import __vite_glob_0_5 from './components/card.js';
import __vite_glob_0_6 from './components/category-icon.js';
import __vite_glob_0_7 from './components/category.js';
import __vite_glob_0_8 from './components/header.js';
import __vite_glob_0_9 from './components/icon.js';
import __vite_glob_0_10 from './components/input.js';
import __vite_glob_0_11 from './components/line.js';
import __vite_glob_0_12 from './components/list.js';
import __vite_glob_0_13 from './components/protection-status-icon.js';
import __vite_glob_0_14 from './components/protection-status-toggle.js';
import __vite_glob_0_15 from './components/revoke-at.js';
import __vite_glob_0_16 from './components/stats.js';
import __vite_glob_0_17 from './components/switch-item.js';
import __vite_glob_0_18 from './components/switch.js';
import __vite_glob_0_19 from './components/text.js';
import __vite_glob_0_20 from './components/toggle.js';
import __vite_glob_0_21 from './components/tooltip.js';
import __vite_glob_0_22 from './components/tracker-name.js';
import __vite_glob_0_23 from './components/tracker-wheel.js';
import define from '../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/action-button-group.js": __vite_glob_0_0,"./components/action-button.js": __vite_glob_0_1,"./components/action.js": __vite_glob_0_2,"./components/badge.js": __vite_glob_0_3,"./components/button.js": __vite_glob_0_4,"./components/card.js": __vite_glob_0_5,"./components/category-icon.js": __vite_glob_0_6,"./components/category.js": __vite_glob_0_7,"./components/header.js": __vite_glob_0_8,"./components/icon.js": __vite_glob_0_9,"./components/input.js": __vite_glob_0_10,"./components/line.js": __vite_glob_0_11,"./components/list.js": __vite_glob_0_12,"./components/protection-status-icon.js": __vite_glob_0_13,"./components/protection-status-toggle.js": __vite_glob_0_14,"./components/revoke-at.js": __vite_glob_0_15,"./components/stats.js": __vite_glob_0_16,"./components/switch-item.js": __vite_glob_0_17,"./components/switch.js": __vite_glob_0_18,"./components/text.js": __vite_glob_0_19,"./components/toggle.js": __vite_glob_0_20,"./components/tooltip.js": __vite_glob_0_21,"./components/tracker-name.js": __vite_glob_0_22,"./components/tracker-wheel.js": __vite_glob_0_23


}),
  { prefix: 'ui', root: 'components' },
);
