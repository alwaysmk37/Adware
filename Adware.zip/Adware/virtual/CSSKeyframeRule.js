var CSSKeyframeRule = {};

export { CSSKeyframeRule as __exports };
