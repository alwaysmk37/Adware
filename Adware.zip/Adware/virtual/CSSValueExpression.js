var CSSValueExpression = {};

export { CSSValueExpression as __exports };
