import { __require as requirePerf_hooks } from '../npm/linkedom/commonjs/perf_hooks.js';

var perf_hooksExports = requirePerf_hooks();

export { perf_hooksExports };
