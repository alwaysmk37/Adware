var CSSConditionRule = {};

export { CSSConditionRule as __exports };
