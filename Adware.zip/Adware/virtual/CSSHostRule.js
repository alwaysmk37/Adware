var CSSHostRule = {};

export { CSSHostRule as __exports };
