var CSSMediaRule = {};

export { CSSMediaRule as __exports };
