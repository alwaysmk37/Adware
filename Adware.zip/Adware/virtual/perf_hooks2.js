var perf_hooks = {};

export { perf_hooks as __exports };
