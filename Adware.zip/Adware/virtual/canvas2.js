var canvas = {exports: {}};

export { canvas as __module };
