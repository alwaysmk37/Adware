import * as __viteBrowserExternal from './__vite-browser-external.js';
import { getAugmentedNamespace } from './_commonjsHelpers.js';

const require$$0 = /*@__PURE__*/getAugmentedNamespace(__viteBrowserExternal);

export { require$$0 as default };
