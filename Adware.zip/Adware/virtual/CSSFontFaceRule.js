var CSSFontFaceRule = {};

export { CSSFontFaceRule as __exports };
