var clone = {};

export { clone as __exports };
