var CSSStyleDeclaration = {};

export { CSSStyleDeclaration as __exports };
