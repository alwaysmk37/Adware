var StyleSheet = {};

export { StyleSheet as __exports };
